import 'package:flutter/material.dart';

void main() {
  runApp(const TasbeehApp());
}

class TasbeehApp extends StatelessWidget {
  const TasbeehApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مسبحة إلكترونية',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: const TasbeehPage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class TasbeehPage extends StatefulWidget {
  const TasbeehPage({super.key});

  @override
  State<TasbeehPage> createState() => _TasbeehPageState();
}

class _TasbeehPageState extends State<TasbeehPage> {
  int count1 = 0;
  int count2 = 0;
  int count3 = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مسبحة إلكترونية'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // الزر الأول
            Text('سبحان الله: $count1', style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  count1++;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding:
                    const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: const Text('سبحان الله', style: TextStyle(fontSize: 20)),
            ),
            const SizedBox(height: 30),

            // الزر الثاني
            Text('الحمد لله: $count2', style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  count2++;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding:
                    const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: const Text('الحمد لله', style: TextStyle(fontSize: 20)),
            ),
            const SizedBox(height: 30),

            // الزر الثالث
            Text('الله أكبر: $count3', style: const TextStyle(fontSize: 22)),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  count3++;
                });
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding:
                    const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: const Text('الله أكبر', style: TextStyle(fontSize: 20)),
            ),
          ],
        ),
      ),
    );
  }
}
